<?php
  // Create database connection
  define('DB_HOST', 'localhost');
define('DB_NAME', 'medicalocr');
define('DB_USER','root');
define('DB_PASSWORD','');
$con=mysql_connect(DB_HOST,DB_USER,DB_PASSWORD) or die("Failed to connect to MySQL: " . mysql_error());

$db=mysql_select_db(DB_NAME,$con) or die("Failed to connect to MySQL: " . mysql_error());


  session_start();
  $uId = $_SESSION['userId'];

function setAlarm(){
  $alarmhrs = $_POST['alarmhrs'];  
  $alarmmins = $_POST['alarmmins']; 
  $alarmsecs = $_POST['alarmsecs']; 
   $ampm = $_POST['ampm'];
   $note = $_POST['note'];
   $uId = $_SESSION['userId'];
   echo $uId;
   echo $note;
 // $dob = $_POST['dob'];
 // $gender = $_POST['gender'];

 // echo $alarmhrs;
   //INSERT INTO remainders (hrs, min, sec, ampm,notes,userId) VALUES (1, 12, 23, 'AM','as ew',12)
	 $query = "INSERT INTO remainders (hrs, min, sec, ampm,notes,userId) VALUES ('$alarmhrs', '$alarmmins', '$alarmsecs', '$ampm','$note','$uId')";
   $data = mysql_query ($query)or die(mysql_error()); 
   if($data) {
    header("Location: profile.php");
    }
}


  if(isset($_POST['submit']))
{
	//echo 'Set Remainder'. $uId;
	setAlarm();
}


  ?>



