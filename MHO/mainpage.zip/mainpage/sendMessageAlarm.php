<?php
require_once "phpmailer/PHPMailerAutoload.php";
$mail = new PHPMailer();

define('DB_HOST', 'localhost');
define('DB_NAME', 'medicalocr');
define('DB_USER','root');
define('DB_PASSWORD','');
$con=mysql_connect(DB_HOST,DB_USER,DB_PASSWORD) or die("Failed to connect to MySQL: " . mysql_error());

$db=mysql_select_db(DB_NAME,$con) or die("Failed to connect to MySQL: " . mysql_error());

function sendMessage(){
	//echo $_POST['name'];
	
		$note = $_POST['name'];
		$mail = new PHPMailer();
		$mail->SMTPDebug = 3;                               
		//Set PHPMailer to use SMTP.
		$mail->isSMTP();            
		//Set SMTP host name                          
		$mail->Host = "smtp.gmail.com";
		//Set this to true if SMTP host requires authentication to send email
		$mail->SMTPAuth = true;                          
		//Provide username and password     
		$mail->Username = "vibhutipratapsingh@gmail.com";                 
		$mail->Password = "#mirandakerr32";                           
		//If SMTP requires TLS encryption then set it
		$mail->SMTPSecure = "tls";                           
		//Set TCP port to connect to 
		$mail->Port = 587;                                   

		$mail->From = "vibhutipratapsingh@gmail.com";
		$mail->FromName = "Vibhuti pratap Singh";

		$mail->addAddress($_POST['email']);

		$mail->isHTML(true);

		$mail->Subject = "Reply from MedicalOCR";
		$mail->Body = "<i> Time to take Medicine</i>";
		$mail->AltBody = $note;

		if(!$mail->send()) 
		{
		    echo "Mailer Error: " . $mail->ErrorInfo;
		} 
		else 
		{
		    header("Location: profile.php");
		}

		
		
	}
	


if($_POST['submit']=='Submit')
{
	//echo 'Submit page';
	 sendMessage();
}

?>