<script src="vendor/jquery/jquery.min.js"></script>
<script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
<link href="vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
<!DOCTYPE html>
<!--[if lt IE 7 ]> <html lang="en" class="no-js ie6 lt8"> <![endif]-->
<!--[if IE 7 ]>    <html lang="en" class="no-js ie7 lt8"> <![endif]-->
<!--[if IE 8 ]>    <html lang="en" class="no-js ie8 lt8"> <![endif]-->
<!--[if IE 9 ]>    <html lang="en" class="no-js ie9"> <![endif]-->
<!--[if (gt IE 9)|!(IE)]><!--> 
<html lang="en" class="no-js"> <!--<![endif]-->
    <head>
        <meta charset="UTF-8" />
        <link href="css/profile.css" rel="stylesheet">
        <link href="css/one-page-wonder.css" rel="stylesheet">
        <!-- <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">  -->
        <title>Medical Helper</title>
        <style type="text/css">
          /* layout.css Style */
            .upload-drop-zone {
              height: 200px;
              border-width: 2px;
              margin-bottom: 20px;
            }

            /* skin.css Style*/
            .upload-drop-zone {
              color: #ccc;
              border-style: dashed;
              border-color: #ccc;
              line-height: 200px;
              text-align: center
            }
            .upload-drop-zone.drop {
              color: #222;
              border-color: #222;
            }
        </style>
		<link rel="stylesheet" type="text/css" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" />
		<link href="https://fonts.googleapis.com/css?family=Raleway:100,100i,200,200i,300,300i,400,400i,500,500i,600,600i,700,700i,800,800i,900,900i" rel="stylesheet">
		
    </head>
    <nav class="navbar navbar-expand-lg navbar-dark navbar-custom fixed-top">
      <div class="container">
        <a class="navbar-brand" href="#">View Profile</a>
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarResponsive" aria-controls="navbarResponsive" aria-expanded="false" aria-label="Toggle navigation">
          <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarResponsive">
          <ul class="navbar-nav ml-auto">
            <!-- <li class="nav-item" data-toggle="modal"  href="#" >
              <a class="nav-link" href="#">Home</a>
            </li>
            <li class="nav-item" data-toggle="modal"  href="#" >
              <a class="nav-link" href="#about">About</a>
            </li>
            <li class="nav-item" data-toggle="modal"  href="#" >
              <a class="nav-link" href="#contact">Contact</a>
            </li> -->
            <li  >
              <a class="nav-link" href="ocrInfoList.php">Saved OCR INFO</a>
            </li>
            <li  >
              <a class="nav-link" href="profile.php">Profile</a>
            </li>
            
            <li class="nav-item" data-toggle="modal">
              <a class="nav-link" href="logout.php">Log Out</a>
            </li>
          </ul>
        </div>
      </div>
    </nav>

    <body>

      <div class="container" style="margin-top: 100px; margin-bottom: 100px">
            <div class="panel panel-default">
              <div class="panel-heading"><strong>Upload Image</strong> <small>To see output</small></div>
              <div class="panel-body">

                <!-- Standar Form -->
                <div style=" visibility: hidden;">
                <?php
                      $test = "";
                      if(file('test.txt')){
                          foreach(file('test.txt') as $line) {
                            $test = $test.$line."<br>";
                             // echo $line. "\n";
                          }
                          echo "<div id='test'>";
                          // echo '"'.$test.'"';
                          echo "</div>";
                          //unlink('test.txt');
                      }
                      
                ?>           
                </div>

                <form action="OCR_Image_upload.php" method="post" enctype="multipart/form-data"   >
                  <div class="form-inline">
                    <div class="form-group">
                      <input type="file" name="image" id="js-upload-files" multiple>
                    </div>
                    <button type="submit" name="upload">Upload files</button>
                  </div>
                </form>
                <form action="updateOCR.php" method="post">
                  <div class="form-group">
                    <label for="exampleFormControlTextarea1">OCR output</label>
                    <textarea name="OCRtext" class="form-control" rows="8" id="myTextTest"  ></textarea>

                  </div>
                  <button type="submit" name="update">Save Info</button>
                </form>
                
              </div>
            </div>
          </div> <!-- /container -->
          <div style=" visibility: hidden;">

             <form >
              <input class="form-control" id="textcheck" value=<?php echo '"'.$test.'"'; ?>  ></textarea>
            </form>
            
          </div>
    </body>
    <script type="text/javascript">
      var s= document.getElementById('textcheck').value;
      var s1= document.getElementById('test').value;
      var result = s.replace(/<br>/g, "\n");
      //var result = result.replace(/\n/g, " ");

       // console.log(document.getElementById('textcheck'));
       // console.log(document.getElementById('textcheck').value);
      document.getElementById('myTextTest').value=result;

    </script>
  </html>