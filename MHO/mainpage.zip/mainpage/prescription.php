<script src="vendor/jquery/jquery.min.js"></script>
<script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
<link href="vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
<!DOCTYPE html>
<!--[if lt IE 7 ]> <html lang="en" class="no-js ie6 lt8"> <![endif]-->
<!--[if IE 7 ]>    <html lang="en" class="no-js ie7 lt8"> <![endif]-->
<!--[if IE 8 ]>    <html lang="en" class="no-js ie8 lt8"> <![endif]-->
<!--[if IE 9 ]>    <html lang="en" class="no-js ie9"> <![endif]-->
<!--[if (gt IE 9)|!(IE)]><!--> 
<html lang="en" class="no-js"> <!--<![endif]-->
    <head>
        <meta charset="UTF-8" />
        <link href="css/profile.css" rel="stylesheet">
        <link href="css/one-page-wonder.css" rel="stylesheet">
        <!-- <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">  -->
        <title>Medical Helper</title>
		<link rel="stylesheet" type="text/css" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" />
		<link href="https://fonts.googleapis.com/css?family=Raleway:100,100i,200,200i,300,300i,400,400i,500,500i,600,600i,700,700i,800,800i,900,900i" rel="stylesheet">
		

    <?php 
      session_start();
      if (!isset($_SESSION['userId'])) {
              header("Location: index.php");
        }
    ?>
    </head>
    <nav class="navbar navbar-expand-lg navbar-dark navbar-custom fixed-top">
      <div class="container">
        <a class="navbar-brand" href="#">Prescription Page</a>
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarResponsive" aria-controls="navbarResponsive" aria-expanded="false" aria-label="Toggle navigation">
          <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarResponsive">
          <ul class="navbar-nav ml-auto">
            <!-- <li class="nav-item" data-toggle="modal"  href="#" >
              <a class="nav-link" href="#">Home</a>
            </li>
            <li class="nav-item" data-toggle="modal"  href="#" >
              <a class="nav-link" href="#about">About</a>
            </li>
            <li class="nav-item" data-toggle="modal"  href="#" >
              <a class="nav-link" href="#contact">Contact</a>
            </li> -->
            <!-- <li class="nav-item" data-toggle="modal" data-target="#signUpModal" >
              <a class="nav-link" href="#">Sign Up</a>
            </li> -->
            <li class="nav-item" data-toggle="modal" data-target="#loginModal">
              <a class="nav-link" href="index.php">Log Out</a>
            </li>
          </ul>
        </div>
      </div>
    </nav>
    <body>
        <div class="container mx-auto" style="margin-top: 100px; margin-bottom: 100px">
      <div class="row" >
      
        <div class="col-xs-12 col-sm-12 col-md-6 col-lg-6 col-xs-offset-0 col-sm-offset-0 col-md-offset-3 col-lg-offset-3 toppad" >
   
   
          <div class="panel panel-info">
            <div class="panel-heading">
              <h3 class="panel-title">Ramesh Thane</h3>
            </div>
            <div class="panel-body">
              <div class="row">
                <div class="col-md-4 col-lg-4 " align="center"> <img alt="User Pic" src="img/profile.png" class="img-circle img-fluid"> </div>

                <div class=" col-md-8 col-lg-8 "> 
                  <div class="modal-body" style=" max-height: calc(100vh - 210px);Fwio" >
                <form class="form-horizontal" action="/action_page.php">
                  <div class="form-group">
                    <!-- <label class="control-label col-sm-2" for="name">Doctor's Name:</label> -->
                    <div class="col-sm-10">
                      <input type="text" class="form-control" id="name" placeholder="Enter Doctor's Name">
                    </div>
                  </div>

                  <div class="form-group">
                    <!-- <label class="control-label col-sm-2" for="email">Deseases:</label> -->
                    <div class="col-sm-10">
                      <input type="email" class="form-control" id="email" placeholder="Deseases Name">
                    </div>
                  </div>

                  <div class="form-group">
                    <!-- <label class="control-label col-sm-2" for="name">Doctor's Name:</label> -->
                    <div class="col-sm-10">
                      <input type="file" class="form-control" id="name" placeholder="Upload Image">
                    </div>
                  </div>
                  <div class="form-group">
                    <!-- <label class="control-label col-sm-2" for="email">Upload Prescribed Report:</label> -->
                    <div class="col-sm-10">
                      <input type="text" class="form-control" id="email" placeholder="Printed Images of Prescription">
                    </div>
                  </div>
                  
                  <div class="form-group">
                    <!-- <label class="control-label col-sm-2" for="email">Last Visit to Doctor:</label> -->
                    <div class="col-sm-10">
                     <P><B>Last Visit to Doctor</B></p>
                      <input type="date" class="form-control" id="email" placeholder="Date">

                    </div>
                  </div>
                  <div class="form-group">
                    <!-- <label class="control-label col-sm-2" for="email">Last Prescribed Check Up:</label>-->
                     <div class="col-sm-10">
                     <P><B>Last Regular Check Up</B></p>
                      <input type="date" class="form-control" id="email" placeholder="Date">
                    </div>
                  </div>
                  
                  <div class="form-group">
                      <div class="col-sm-10">
                      <P><B>Morning Reminder </B></p>
                      <input type="time" class="form-control" id="time" placeholder="00:00:AM">
                    </div>
                  </div>
                  <div class="form-group">
                    
                    <div class="col-sm-10"> 
                    <P><B>Afternoon Reminder</B></p>
                      <input type="time" class="form-control" id="time" placeholder="00:00:AM">
                    </div>
                  </div>
                  <div class="form-group">
                    
                    <div class="col-sm-10"> 
                    <P><B>Evening Reminder</B></p>
                      <input type="time" class="form-control" id="time" placeholder="00:00:AM">
                    </div>
                  </div>
                  <div class="form-group"> 
                    <div class="col-sm-offset-2 col-sm-10" >
                      <a href="Editprofile.php" class="btn btn-success" role="button" aria-disabled="true">Privous Page</a>
                      <a href="profile.php" class="btn btn-success" role="button" aria-disabled="true">Save</a>
                    </div>
                  </div>
                </form>
            </div>
                     <!-- <a href="profile.php" class="btn btn-success" role="button" aria-disabled="true">Submit</a>
                      <button type="submit" class="btn btn-success">Submit</button></a>
                      <button type="button" class="btn btn-danger" data-dismiss="modal">Close</button> -->
                <!-- <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                <button type="button" class="btn btn-primary">Save changes</button> -->
            <div class="modal-footer">
                <!-- <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                <button type="button" class="btn btn-primary">Save changes</button> -->
            </div>
        </div>
    </div>
</div>
    
            
          </div>
        </div>
      </div>
          <!-- <footer class="py-5 bg-black">
      <div class="container">
        <p class="m-0 text-center text-white small">MNNIT ALLLAHABAD</p>
        <p class="m-0 text-center text-white small">Group 3</p>
      </div>
      <!-- /.container -->
    </footer>
    </body>

</html>