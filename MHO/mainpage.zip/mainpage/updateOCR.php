<?php
  // Create database connection
  define('DB_HOST', 'localhost');
define('DB_NAME', 'medicalocr');
define('DB_USER','root');
define('DB_PASSWORD','');
$con=mysql_connect(DB_HOST,DB_USER,DB_PASSWORD) or die("Failed to connect to MySQL: " . mysql_error());

$db=mysql_select_db(DB_NAME,$con) or die("Failed to connect to MySQL: " . mysql_error());
  session_start();
  $uId = $_SESSION['userId'];

  // Initialize message variable
  $msg = "";

  // If upload button is clicked ...
  if (isset($_POST['update'])) {
  	// Get image name
  	$ocrtext = $_POST['OCRtext'];
    $userID = $uId;
  	// Get text
  	//$image_text = mysqli_real_escape_string($db, $_POST['image_text']);

  	// image file directory
  	
//$query = "INSERT INTO ocr (ocrtext,userID) VALUES ('$ocrtext','$userID')";
  	$query = "INSERT INTO ocr (ocrtext,userID) VALUES ('$ocrtext','$userID');";
  	// execute query
  	 $data = mysql_query ($query)or die(mysql_error()); 
     if($data) {
        echo '<script> alert "YOUR REGISTRATION IS COMPLETED..."; </script>';
        unlink('test.txt');
        header("Location: checkOCR.php"); 
      }
  }
  //$result = mysqli_query($db, "SELECT * FROM users");
?>