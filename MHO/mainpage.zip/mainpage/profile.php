<script src="vendor/jquery/jquery.min.js"></script>
<script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
<link href="vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
<!DOCTYPE html>
<!--[if lt IE 7 ]> <html lang="en" class="no-js ie6 lt8"> <![endif]-->
<!--[if IE 7 ]>    <html lang="en" class="no-js ie7 lt8"> <![endif]-->
<!--[if IE 8 ]>    <html lang="en" class="no-js ie8 lt8"> <![endif]-->
<!--[if IE 9 ]>    <html lang="en" class="no-js ie9"> <![endif]-->
<!--[if (gt IE 9)|!(IE)]><!--> 
<html lang="en" class="no-js"> <!--<![endif]-->
    <head>
        <meta charset="UTF-8" />
        <link href="css/profile.css" rel="stylesheet">
        <link href="css/one-page-wonder.css" rel="stylesheet">
        <!-- <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">  -->
        <title>Medical Helper</title>
		<link rel="stylesheet" type="text/css" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" />
		<link href="https://fonts.googleapis.com/css?family=Raleway:100,100i,200,200i,300,300i,400,400i,500,500i,600,600i,700,700i,800,800i,900,900i" rel="stylesheet">
		
    </head>
    <nav class="navbar navbar-expand-lg navbar-dark navbar-custom fixed-top">
      <div class="container">
        <a class="navbar-brand" href="#">View Profile</a>
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarResponsive" aria-controls="navbarResponsive" aria-expanded="false" aria-label="Toggle navigation">
          <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarResponsive">
          <ul class="navbar-nav ml-auto">
            <!-- <li class="nav-item" data-toggle="modal"  href="#" >
              <a class="nav-link" href="#">Home</a>
            </li>
            <li class="nav-item" data-toggle="modal"  href="#" >
              <a class="nav-link" href="#about">About</a>
            </li>
            <li class="nav-item" data-toggle="modal"  href="#" >
              <a class="nav-link" href="#contact">Contact</a>
            </li> -->
            <li  >
              <a class="nav-link" href="docter.php">Docters</a>
            </li>
            <li  >
              <a class="nav-link" href="checkOCR.php">Use OCR</a>
            </li>
            <li class="nav-item" data-toggle="modal" data-target="#setAlarm" >
              <a class="nav-link" href="#">Set Reminder</a>
            </li>
            <li class="nav-item" data-toggle="modal">
              <a class="nav-link" href="logout.php">Log Out</a>
            </li>
          </ul>
        </div>
      </div>
    </nav>
    <body>
        <div class="container mx-auto" style="margin-top: 100px; margin-bottom: 100px">
      <div class="row" >
      
        <div class="col-xs-12 col-sm-12 col-md-6 col-lg-6 col-xs-offset-0 col-sm-offset-0 col-md-offset-3 col-lg-offset-3 toppad" >
   
   
          <div class="panel panel-info">
            <div class="panel-heading">
              <h3 class="panel-title">
                <?php 
                  session_start();
                  if (!isset($_SESSION['userId'])) {
                          header("Location: index.php");
                    }
                  $db = mysqli_connect("localhost", "root", "", "medicalocr");
                  $userId=$_SESSION['userId'];
                  $result = mysqli_query($db, "SELECT * FROM users WHERE userId='$userId';");
                  $row = mysqli_fetch_array($result);
                    echo $_SESSION['username'];
                    // echo $row['image'];

                    // echo $_SESSION['userId'];
                //}
                ?>
              </h3>
            </div>
            <div class="panel-body">
              <div class="row">
                <div class="col-md-4 col-lg-4 " align="center">

                  <?php
                    if($row['image']){
                        echo "<img alt='User pic' src='images/".$row['image']."' class='img-circle img-fluid' height='200' >";
                       // echo <img alt="User Pic" src="images/.'$row['image']'." class="img-circle img-fluid"  height="200">
                    }
                    else
                        echo '<img alt="User Pic" src="img/profile.png" class="img-circle img-fluid"  height="200">'
                 ?>
                 <br>
                <div>
                  <!-- <button type="button" onclick="myFunction()" id="upload_button" class="button">Upload New Image</button> -->
                  <button type="button" class="btn btn-info" data-toggle="modal" data-target="#myModal">Upload New Image</button>
                </div>
                </div>

                <div class=" col-md-8 col-lg-8 "> 
                  <table class="table table-user-information">
                    <tbody>
                      <tr>
                        <td>User Name:</td>
                        <td><?php echo $row['username']; ?></td>
                      </tr>
                      <tr>
                        <td>Doctor Name:</td>
                        <td><?php echo $row['doctorName']; ?></td>
                      </tr>   
                      <tr>
                        <td>DoB:</td>

                        <td><?php echo $row['dob']; ?></td>
                      </tr>
                      
                      <tr>
                        <td>Gender:</td>
                        <td><?php echo $row['gender']; ?></td>
                      </tr>
                        <tr>
                        <td>Address:</td>
                        <td><?php echo $row['address']; ?></td>
                      </tr>
                      <tr>
                        <td>Email:</td>
                        <td><a href="mailto:info@support.com"><?php echo $row['email']; ?></a></td>
                      </tr>
                        <td>Phone Number:</td>
                        <td><?php echo $row['contact']; ?>
                        </td>                           
                      </tr>
                      <tr>
                        <td>Marital Statuse:</td>
                        <td><?php echo $row['maritalStatuse']; ?></td>
                      </tr>
                      <!-- <tr>
                        <td>Last Visit to Doctor:</td>
                        <td>June 11,2017</td>
                      </tr>  -->            
                      </tbody>
                  </table>
                  
                 <a href="Editprofile.php" class="btn btn-success" role="button" aria-disabled="true">Edit</a>
                  
                </div>
              </div>
            </div>
                 
            
          </div>
        </div>
        <div  style="margin-top: 100px; margin-bottom: 100px" class="col-xs-12 col-sm-12 col-md-6 col-lg-6 col-xs-offset-0 col-sm-offset-0 col-md-offset-3 col-lg-offset-3 toppad" >
          <table class="table table-condensed"  id="mytab1">
            
            <thead>
              <tr>
                <th>Time</th>
                <th>Notes</th>
                <th>Options</th>
              </tr>
            </thead>
            <tbody>
             <?php
             $alarm = mysqli_query($db, "SELECT * FROM remainders WHERE userId='$userId';");
             $rowAlarm = $alarm->fetch_array();
             while($rowAlarm[0]) {
                
                echo '<tr>';
                echo '<td id="time">';
                echo $rowAlarm['hrs'].':'.$rowAlarm['min'].':'.$rowAlarm['sec'].' '.$rowAlarm['ampm'];
                echo '</td>';
                echo '<td id="note">';
                echo $rowAlarm['notes'];
                echo '</td>';
                echo '</td>';
                echo '<td id="note">';
                // echo '<a href="updateAlarm.php/?id='.$rowAlarm['id'].'">';
                // echo 'update ';
                // echo '</a>';
                echo '<a href="deleteAlarm.php/?id='.$rowAlarm['id'].'">';
                echo 'delete';
                echo '</a>';
                echo '</td>';
                echo '</tr>';
                $rowAlarm = $alarm->fetch_array();
              } 
            ?>
            </tbody>
              
          </table>
        </div>

        <div id="myDIV">
          <form action="sendMessageAlarm.php" id="myFORM"  method="POST">
            <input type="text" name="note" id ="myNote"><br>
            <input type="email" name="email" <?php
            echo 'value='.$row['email']
            ?>
            ><br>
            <input type="submit" id = 'submit1' name='submit' value="Submit">
          </form>
          This is my DIV element.
        </div>
        <div class="modal fade" id="myModal" role="dialog">
                    <div class="modal-dialog">
                    
                      <!-- Modal content-->
                      <div class="modal-content">
                        <div class="modal-header">
                          <h4 class="modal-title">Upload Image</h4>
                          <button type="button" class="close" data-dismiss="modal">&times;</button>
                          
                        </div>
                        <div class="modal-body">
                          <form method="POST" action="profile_upload.php" enctype="multipart/form-data">
                            <div class="form-group">
                              <input type="file" class="form-control-file" name="image" id="exampleFormControlFile1">
                              <button type="submit" name="upload">POST</button>
                            </div>
                          </form>
                        </div>
                        <div class="modal-footer">
                          <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                        </div>
                      </div>
                      
                    </div>
                  </div>

      </div>
          <footer class="py-5 bg-black">
      <div class="container">
        <p class="m-0 text-center text-white small">MNNIT ALLLAHABAD</p>
        <p class="m-0 text-center text-white small">Group 3</p>
      </div>
      <!-- /.container -->
    </footer>

    <div class="modal fade" id="setAlarm" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
      <div class="modal-dialog" role="document">
          <div class="modal-content">

                  <div class="modal-header">
                      <h5 class="modal-title" id="exampleModalLabel">Set Remainder</h5>
                      <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                          <span aria-hidden="true">&times;</span>
                      </button>
                  </div>
                  <div class="modal-body">
                      <form class="form-horizontal" method="POST" action="setRemainder.php">
                        <div class="row">
                          <div class="col-sm-1">
                          </div>
                          <div class="col-sm-2">
                            <div class="form-group">
                              
                              <select name="alarmhrs" id='alarmhrs'>
                                
                              </select>
                            </div>
                          </div>
                          <div class="col-sm-2">
                            <div class="form-group">
                              
                              <select name="alarmmins" id='alarmmins'>
                                
                              </select>
                            </div>
                          </div>
                          <div class="col-sm-2">
                            <div class="form-group">
                              
                              <select  name="alarmsecs" id='alarmsecs' >
                                
                              </select>
                            </div>
                          </div>
                          <div class="col-sm-2">
                            <div class="form-group">
                              
                              <select name="ampm" id='ampm' >
                                <option value="AM">AM</option>
                                <option value="PM">PM</option>
                                
                              </select>
                            </div>
                          </div>
                        </div>
                         <div class="form-group">
                          <label for="note">Add notes</label>
                          <textarea class="form-control" id="note" name="note" rows="3"></textarea>
                        </div
                        
                        
                        <div class="form-group"> 
                          <div class="col-sm-offset-2 col-sm-10">
                            <!-- <a href="profile.php"> -->
                            <!-- <a href="profile.php" class="btn btn-success" role="button" aria-disabled="true">Submit</a> -->
                            <button type="submit" name="submit" class="btn btn-success">Submit</button></a>
                            <button type="button" class="btn btn-danger" data-dismiss="modal">Close</button>
                          </div>
                        </div>
                      </form>
                  </div>
                  <div class="modal-footer">
                      
                      <!-- <button type="button" class="btn btn-primary">Save changes</button> -->
                  </div>
              </div>
          </div>
      </div>
    </body>
    <script>
      function hoursMenu(){

        var select = document.getElementById('alarmhrs');
        var hrs = 12

        for (i=1; i <= hrs; i++) {
          select.options[select.options.length] = new Option( i < 10 ? "0" + i : i, i);
          
        }
      }
      hoursMenu();

      function minMenu(){

          var select = document.getElementById('alarmmins');
          var min = 59;

          for (i=0; i <= min; i++) {
            select.options[select.options.length] = new Option(i < 10 ? "0" + i : i, i);
          }
        }
        minMenu();

        function secMenu(){

          var select = document.getElementById('alarmsecs');
          var sec = 59;

          for (i=0; i <= sec; i++) {
            select.options[select.options.length] = new Option(i < 10 ? "0" + i : i, i);
          }
        }
        secMenu();

        function addZero(time) {

            return (time < 10) ? "0" + time : time;
          
        }
        function checkAlarm(){
          var alarmTime= new Array();
          var alarmNotes= new Array();
          var table = document.getElementById("mytab1");
         
          for (var i = 1, row; row = table.rows[i]; i++) {
             
              var str = row.cells[0].innerHTML;
              var note = row.cells[1].innerHTML;
              console.log(note);
              alarmNotes.push(note);
              var res = str.split(":");
              //console.log(res);
              var selectedHour = res[0];
              var selectedMin = res[1];
              str = res[2];
              res = str.split(" ");
              var selectedSec = res[0];
              var selectedAP = res[1];
              alarmTime.push(addZero(selectedHour) + ":" + addZero(selectedMin) + ":" + addZero(selectedSec) + selectedAP);
              // console.log(sec); 
          }
          console.log(alarmTime);
          setInterval(function(){

          var date = new Date();
          
          var hours = (12 - (date.getHours()));
          // var hours = date.getHours();
          
          var minutes = date.getMinutes();
          
          var seconds = date.getSeconds();
          
          var ampm = (date.getHours()) < 12 ? 'AM' : 'PM';


          //convert military time to standard time

          if (hours < 0) {
            hours = hours * -1;
          } else if (hours == 00) {
            hours = 12;
          } else {
            hours = hours;
          }
          
          var currentTime = addZero(hours) + ":" + addZero(minutes) + ":" + addZero(seconds) + "" + ampm;
          //console.log(currentTime);
          for(var c=0;c<alarmTime.length;c++){
            //console.log(currentTime +" "+ alarmTime[c]);
            if (alarmTime[c] == currentTime) {
              
              document.getElementById('myNote').value=alarmNotes[c];
              document.getElementById('submit1').click();
               // document.getElementById("myFORM").submit();
              //sound.play();
              //console.log("Set");
            }  
          }
          

        },1000);

        }
        checkAlarm();

        var x = document.getElementById("myDIV");
        x.style.display = "none";

        // $("#rec").submit();


function myFunction() {
    document.getElementById("upload_button").innerHTML = "Hello World";
}
</script>

</html>