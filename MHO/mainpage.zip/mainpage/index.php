<!DOCTYPE html>
<html lang="en">

  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>Medical Helper</title>
    <!-- Bootstrap core CSS -->
    <link href="vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">

    <!-- Custom fonts for this template -->
    <link href="https://fonts.googleapis.com/css?family=Catamaran:100,200,300,400,500,600,700,800,900" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css?family=Lato:100,100i,300,300i,400,400i,700,700i,900,900i" rel="stylesheet">

    <!-- Custom styles for this template -->
    <link href="css/one-page-wonder.css" rel="stylesheet">

  </head>

  <body>

    <!-- Navigation -->
    <nav class="navbar navbar-expand-lg navbar-dark navbar-custom fixed-top">
      <div class="container">
        <a class="navbar-brand" href="#">Medical Helper</a>
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarResponsive" aria-controls="navbarResponsive" aria-expanded="false" aria-label="Toggle navigation">
          <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarResponsive">
          <ul class="navbar-nav ml-auto">
            <li class="nav-item" data-toggle="modal"  href="#" >
              <a class="nav-link" href="#">Home</a>
            </li>
            <li class="nav-item" data-toggle="modal"  href="#" >
              <a class="nav-link" href="#about">About OCR</a>
            </li>
                      
            <li class="nav-item" data-toggle="modal" data-target="#loginModal">
              <a class="nav-link" href="#">Log In</a>
            </li>
            <li class="nav-item" data-toggle="modal" data-target="#signUpModal" >
              <a class="nav-link" href="#">Sign Up</a>
            <li class="nav-item" data-toggle="modal"  href="#" >
              <a class="nav-link" href="#contact">Contact US</a>
            </li>
            </li>
          </ul>
        </div>
      </div>
    </nav>
<div class="modal fade" id="signUpModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document" >
        <div class="modal-content">

            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLabel">Create Account</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body" style=" max-height: calc(100vh - 210px);overflow-y: auto;" >
                <form class="form-horizontal" method="POST" action="connectivity-sign-up.php">
                  <div class="form-group">
                    <!-- <label class="control-label col-sm-2" for="name">Name:</label> -->
                    <div class="col-sm-10">
                      <input type="text" class="form-control" id="name" name="name" placeholder="Enter Name">
                    </div>
                  </div>

                  <div class="form-group">
                    <!-- <label class="control-label col-sm-2" for="email">Email:</label> -->
                    <div class="col-sm-10">
                      <input type="email" class="form-control" id="email" name="email" placeholder="Enter Email">
                    </div>
                  </div>
                  <div class="form-group">
                  <!-- <label class="control-label col-sm-2" for="email">Mobile number:</label> -->
                    <div class="col-sm-10">
                      <input type="text" class="form-control" id="mobileNumber" name="mobileNumber" placeholder="Enter Mobile Number">
                    </div>
                  </div>

                  <div class="form-group">
                  <!-- <label class="control-label col-sm-2" for="email">Mobile number:</label> -->
                    <div class="col-sm-10">
                      <input type="text" class="form-control" id="doctorName" name="doctorName" placeholder="Docter Name">
                    </div>
                  </div>

                   <div class="form-group">
                    <div class="col-sm-10">
                     <!-- <label class="radio inline" for="gender-0"> -->
                      <input name="gender" id="gender-0" name ="gender" value="Male" checked="checked" type="radio">
                      Male
                    <!-- </label> -->
                    <!-- <label class="radio inline" for="gender-1"> -->
                      <input name="gender" id="gender-1" name ="gender" value="Female" type="radio">
                      Female

                    <!-- </label> -->
                  </div>
                  </div>
                  <div class="form-group">
                    <div class="col-sm-10">
                     <!-- <label class="radio inline" for="gender-0"> -->
                      <input  name ="maritalStatuse" value="Married" checked="checked" type="radio">
                      Married
                    <!-- </label> -->
                    <!-- <label class="radio inline" for="gender-1"> -->
                      <input  name ="maritalStatuse" value="Unmarried" type="radio">
                      Unmarried

                    <!-- </label> -->
                  </div>
                  </div>
                  <div class="form-group">
                    <!-- <label class="control-label col-sm-2" for="email">DoB:</label> -->
                    <div class="col-sm-10">
                      <input type="date" class="form-control" id="dob" name="dob" placeholder="Date of Birth">
                    </div>
                  </div>
                  <div class="form-group">
                    <!-- <label class="control-label col-sm-2" for="pwd">Password:</label> -->
                    <div class="col-sm-10"> 
                      <input type="password" class="form-control" id="pwd" name="pwd" placeholder="Enter Password">
                    </div>
                  </div>
                  <div class="form-group">
                    <!-- <label class="control-label col-sm-2" for="pwd">Confirm Password:</label> -->
                    <div class="col-sm-10"> 
                      <input type="password" class="form-control" name="cpwd" id="cpwd" placeholder="Confirm Password">
                    </div>
                  </div>
                  <!-- <div class="form-group"> 
                    <div class="col-sm-offset-2 col-sm-10">
                      <div class="checkbox">
                        <label><input type="checkbox"> I Agree</label>
                      </div>
                    </div>
                  </div> -->
                  <div class="form-group"> 
                    <div class="col-sm-offset-2 col-sm-10" >
                      <!-- <a href="profile.php" class="btn btn-success" role="button" aria-disabled="true">Submit</a> -->
                      <button type="submit" name="submit" class="btn btn-success">Submit</button></a>
                      <button type="button" class="btn btn-danger" data-dismiss="modal">Close</button>
                    </div>
                  </div>
                </form>
            </div>
                     <!-- <a href="profile.php" class="btn btn-success" role="button" aria-disabled="true">Submit</a>
                      <button type="submit" class="btn btn-success">Submit</button></a>
                      <button type="button" class="btn btn-danger" data-dismiss="modal">Close</button> -->
                <!-- <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                <button type="button" class="btn btn-primary">Save changes</button> -->
            <div class="modal-footer">
                <!-- <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                <button type="button" class="btn btn-primary">Save changes</button> -->
            </div>
        </div>
    </div>
</div>

<div class="modal fade" id="loginModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">

            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLabel">Sign In</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <form class="form-horizontal" method="POST" action="connectivity-sign-in.php">
                  <div class="form-group">
                    <!-- <label class="control-label col-sm-2" for="email">Email:</label> -->
                    <div class="col-sm-10">
                      <input type="text" class="form-control" name="name" id="email" placeholder="username/Email">
                    </div>
                  </div>
                  <div class="form-group">
                    <!-- <label class="control-label col-sm-2" for="pwd">Password:</label> -->
                    <div class="col-sm-10"> 
                      <input type="password" class="form-control" id="pwd" name="pwd" placeholder="Password">
                    </div>
                  </div>
                  <div class="form-group"> 
                    <div class="col-sm-offset-2 col-sm-10">
                      <div class="checkbox">
                        <a href ="forgot.php" > Forgot Password ?</a>
                      </div>
                    </div>
                  </div>
                  <div class="form-group"> 
                    <div class="col-sm-offset-2 col-sm-10">
                      <!-- <a href="profile.php"> -->
                      <!-- <a href="profile.php" class="btn btn-success" role="button" aria-disabled="true">Submit</a> -->
                      <button type="submit" name="submit" class="btn btn-success">Submit</button></a>
                      <button type="button" class="btn btn-danger" data-dismiss="modal">Close</button>
                    </div>
                  </div>
                </form>
            </div>
            <div class="modal-footer">
                
                <!-- <button type="button" class="btn btn-primary">Save changes</button> -->
            </div>
        </div>
    </div>
</div>

    <!-- <header class="masthead text-center text-white">
      <div class="masthead-content">
        <div class="container">
          <h1 class="masthead-heading mb-0">Always laugh when you can</h1>
          <h2 class="masthead-subheading mb-0">It's a cheap Medicine</h2>
          <a href="#" class="btn btn-primary btn-xl rounded-pill mt-5">Learn More</a>
        </div>
      </div>
      <div class="bg-circle-1 bg-circle"></div>
      <div class="bg-circle-2 bg-circle"></div>
      <div class="bg-circle-3 bg-circle"></div>
      <div class="bg-circle-4 bg-circle"></div>
    </header> -->

    <div id="carouselExampleIndicators" class="carousel slide" data-ride="carousel">
      <ol class="carousel-indicators">
        <li data-target="#carouselExampleIndicators" data-slide-to="0" class="active"></li>
        <li data-target="#carouselExampleIndicators" data-slide-to="1"></li>
        <li data-target="#carouselExampleIndicators" data-slide-to="2"></li>
      </ol>
      <div class="carousel-inner" role="listbox">
        <div class="carousel-item active">
          <img class="d-block img-fluid" src="img/1.jpg" alt="First slide" style="width:100%;height:550px;">
          <div class="carousel-caption d-none d-md-block">
            <h3 style ="color: #2f3238;">Hippocrates</h3>
            <p style ="color: #273a02;">Let food be thy medicine and medicine be thy food</p>
          </div>
        </div>
        <div class="carousel-item">
          <img class="d-block img-fluid" src="img/2.jpg" alt="Second slide" style="width:100%;height:550px;">
          <div class="carousel-caption d-none d-md-block">
            <h3 style ="color: #2f3238;">Chuck Palahniuk</h3>
            <p style ="color: #273a02;">After you find out all the things that can go wrong, your life becomes less about living and more about waiting.</p>
          </div>
        </div>
        <div class="carousel-item">
          <img class="d-block img-fluid" src="img/3.jpg" alt="Third slide" style="width:100%;height:550px;">
          <div class="carousel-caption d-none d-md-block">
            <h3 style ="color: #2f3238;">Voltaire</h3>
            <p style ="color: #273a02;">The art of medicine consists of amusing the patient while nature cures the disease</p>
          </div>
        </div>
      </div>
      <a class="carousel-control-prev" href="#carouselExampleIndicators" role="button" data-slide="prev">
        <span class="carousel-control-prev-icon" ></span>
        <span class="sr-only">Previous</span>
      </a>
      <a class="carousel-control-next" href="#carouselExampleIndicators" role="button" data-slide="next">
        <span class="carousel-control-next-icon" ></span>
        <span class="sr-only">Next</span>
      </a>
    </div>

  <div id="about">
    <section >
      <div class="container" >
        <div class="row align-items-center">
          <div class="col-lg-6 order-lg-2">
            <div class="p-5">
              <img class="img-fluid rounded-circle" src="img/patient.jpg" alt="">
            </div>
          </div>
          <div class="col-lg-6 order-lg-1">
            <div class="p-5">
              <h2 class="display-4">What it is?</h2>
              <h4 style="color:   #3CB371;">Taking medicines to be cured is good but when to take it and what dose to take is more important</h4>
              <p>We often forget to take medicines at suggested time by our doctor. Many times, it is the case that
                we even don't remember that what dose of a particular medicine we have to take. Medical Helper is a solution
                for such kind of situations. The Medical Helper is an innovative system for any user mostly targetting the aged population.
                Here you can set a reminder about when you have to take the medicines prescribed by your doctor.
                Additionally, it also reminds you that when you have to purchase the medicine again to avoid a gap in 
                prescribed medicine course.
              </p>
              
            <p>
              For more ease, the user is also provided to add the addiotnal information  with medicine name like  medicine shape and color while setting a reminder.
            </p>
            
            </div>
          </div>
        </div>
      </div>
    </section>

    <section>
      <div class="container">
        <div class="row align-items-center">
          <div class="col-lg-6">
            <div class="p-5">
              <img class="img-fluid rounded-circle" src="img/doctors-1.jpg" alt="">
            </div>
          </div>
          <div class="col-lg-6">
            <div class="p-5">
              <h2 class="display-4">We will remind you again and again !</h2>
              <p>Once a reminder is all set, we will send a message or email to remind the user to take the medicine at the time
listed in the reminder by user. The reminder will also include all information about that medicine that is already given by the user.
            </p>
            </div>
          </div>
        </div>
      </div>
    </section>

    <section>
      <div class="container">
        <div class="row align-items-center">
          <div class="col-lg-6 order-lg-2">
            <div class="p-5">
              <img class="img-fluid rounded-circle" src="img/remainder.jpg" alt="">
            </div>
          </div>
          <div class="col-lg-6 order-lg-1">
            <div class="p-5">
              <h2 class="display-4">How it works?</h2>
              <p>OCR (optical character recognition) is the recognition of printed or written text characters by a computer. This involves photoscanning of the text character-by-character, analysis of the scanned-in image, and then translation of the character image into character codes.</p>
            </div>
          </div>
        </div>
      </div>
    </section>
    <section>
      <div class="container">
        <div class="row align-items-center">
          <div class="col-lg-6">
            <div class="p-5">
              <img class="img-fluid rounded-circle" src="img/doctors-1.jpg" alt="">
            </div>
          </div>
          <div class="col-lg-6">
            <div class="p-5">
              <h2 class="display-4">About OCR</h2>
              <p>Optical Character Recognition, or OCR, is a technology that enables you to
convert different types of documents,such as scanned paper documents,handwritten or printed text, PDF 
files or images captured by a digital camera into editable and searchable data.</p>
<p>
Here, you don't need to type the name of the medicines during the setting of an alarm. All you have to do is
just upload the printed text of your purchased medicine bill and it will extract the medicine names by itself. 
Even it allows you to preview once the medicine names are extracted in case you want to edit the names. So OCR feature
just saves your time to setting a reminder faster.</p>
            </div>
          </div>
        </div>
      </div>
    </section>
   </div>
   <!-- contact  -->
   <section id="contact">
  <div class="container">
    <div class="well well-sm">
      <h3><strong>Contact Us</strong></h3>
    </div>
  
  <div class="row">
    <div class="col-md-7">
    <!--   <iframe src="//www.google.com/maps/embed/v1/place?q=Harrods,Brompton%20Rd,%20UK
      &zoom=17
      &key=YOUR_API_KEY">
  </iframe> -->
  <iframe src="//www.google.com/maps/embed/v1/place?q=MNNIT,ALLLAHABAD
      &zoom=17
      &key=AIzaSyCIeixir1tBf7T_sHs38xMnc8Ki1YLNmcc"
      width="100%" height="315" frameborder="0" style="border:0" allowfullscreen>
  </iframe>
    <!--     <iframe src="https://www.google.com/maps/embed?pb=!1m10!1m8!1m3!1d3736489.7218514383!2d90.21589792292741!3d23.857125486636733!3m2!1i1024!2i768!4f13.1!5e0!3m2!1sen!2sbd!4v1506502314230" width="100%" height="315" frameborder="0" style="border:0" allowfullscreen></ifram -->
      </div>

      <div class="col-md-5">
          <h4><strong>Get in Touch</strong></h4>
        <form method="POST" action="mailhandler.php">
          <div class="form-group">
            <input type="text" class="form-control" name="name" value="" placeholder="Name">
          </div>
          <div class="form-group">
            <input type="email" class="form-control" name="email" value="" placeholder="E-mail">
          </div>
          <div class="form-group">
            <input type="tel" class="form-control" name="phone" value="" placeholder="Phone">
          </div>
          <div class="form-group">
            <textarea class="form-control" name="message" rows="3" placeholder="Message"></textarea>
          </div>
          <button class="btn btn-default" type="submit" name="submit">
              <i class="fa fa-paper-plane-o" aria-hidden="true"></i> Submit
          </button>
        </form>
      </div>
    </div>
  </div>
</section>
   <!-- <section id="contact">
      <div class="container">
        <h2 class="text-center text-uppercase text-secondary mb-0">Contact Us</h2>
        <hr class="star-dark mb-5">
        <div class="row">
          <div class="col-lg-8 mx-auto"> -->
            <!-- To configure the contact form email address, go to mail/contact_me.php and update the email address in the PHP file on line 19. -->
            <!-- The form should work on most web servers, but if the form is not working you may need to configure your web server differently. -->
            <!-- <form name="sentMessage" id="contactForm" novalidate="novalidate">
              <div class="control-group">
                <div class="form-group floating-label-form-group controls mb-0 pb-2">
                  <label>Name</label>
                  <input class="form-control" id="name" type="text" placeholder="Name" required="required" data-validation-required-message="Please enter your name.">
                  <p class="help-block text-danger"></p>
                </div>
              </div>
              <div class="control-group">
                <div class="form-group floating-label-form-group controls mb-0 pb-2">
                  <label>Email Address</label>
                  <input class="form-control" id="email" type="email" placeholder="Email Address" required="required" data-validation-required-message="Please enter your email address.">
                  <p class="help-block text-danger"></p>
                </div>
              </div>
              <div class="control-group">
                <div class="form-group floating-label-form-group controls mb-0 pb-2">
                  <label>Phone Number</label>
                  <input class="form-control" id="phone" type="tel" placeholder="Phone Number" required="required" data-validation-required-message="Please enter your phone number.">
                  <p class="help-block text-danger"></p>
                </div>
              </div>
              <div class="control-group">
                <div class="form-group floating-label-form-group controls mb-0 pb-2">
                  <label>Message</label>
                  <textarea class="form-control" id="message" rows="5" placeholder="Message" required="required" data-validation-required-message="Please enter a message."></textarea>
                  <p class="help-block text-danger"></p>
                </div>
              </div>
              <br>
              <div id="success"></div>
              <div class="form-group">
                <button type="submit" class="btn btn-info btn-xl" id="sendMessageButton">Send</button>
              </div>
            </form>
          </div>
        </div>
      </div>
    </section> -->
    <!-- Footer -->
    <footer class="py-5 bg-black">
      <div class="container">
        <p class="m-0 text-center text-white small">MNNIT ALLLAHABAD</p>
        <p class="m-0 text-center text-white small">Group 3</p>
      </div>
      <!-- /.container -->
    </footer>

    <!-- Bootstrap core JavaScript -->
    <script src="vendor/jquery/jquery.min.js"></script>
    <script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

  </body>

<script>
// Get the modal
var modal = document.getElementById('id01');

// When the user clicks anywhere outside of the modal, close it
window.onclick = function(event) {
    if (event.target == modal) {
        modal.style.display = "none";
    }
}
</script>
<?php
 include("config.php");
    // if (isset($_POST['submit']))
    //   {   
         

    //       session_start();

    //       $username=$_POST['username'];
    //       $password=$_POST['password'];

    //       $_SESSION['login_user']=$username;
           
    //       $query = mysql_query("SELECT username FROM login WHERE username='$username' and password='$password'");

    //        if (mysql_num_rows($query) != 0)
    //       {

    //            echo "<script language='javascript' type='text/javascript'> location.href='home.php' </script>"; 
    //         }

    //         else
    //         {
    //             echo "<script type='text/javascript'>alert('User Name Or Password Invalid!')</script>";
    //       }

    // }
    
?>


</html>
