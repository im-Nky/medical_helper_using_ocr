<?php
  // Create database connection
 define ('SITE_ROOT', realpath(dirname(__FILE__)));
  // echo "abc";
  session_start();
  $uId = $_SESSION['userId'];

  // Initialize message variable
  $msg = "";
  // echo $_POST['upload'];
  // If upload button is clicked ...
  if (isset($_POST['upload'])) {
  	// Get image name
  	$image = $_FILES['image']['name'];
    // echo $image;
  	// Get text
  	//$image_text = mysqli_real_escape_string($db, $_POST['image_text']);

  	// image file directory
  	$target = "ocrImages/".basename($image);

  	echo $target;

  	if (move_uploaded_file($_FILES['image']['tmp_name'], SITE_ROOT.'\\'.$target)) {
  		$msg = "Image uploaded successfully";
      echo $msg;
      exec("tesseract.exe ".$target." test");


      header("Location: checkOCR.php");
  	}else{
  		$msg = "Failed to upload image";
      echo $msg;
  	}
  }
  //$result = mysqli_query($db, "SELECT * FROM users");
?>
