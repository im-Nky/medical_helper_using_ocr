<?php
  // Create database connection
  define('DB_HOST', 'localhost');
define('DB_NAME', 'medicalocr');
define('DB_USER','root');
define('DB_PASSWORD','');
$con=mysql_connect(DB_HOST,DB_USER,DB_PASSWORD) or die("Failed to connect to MySQL: " . mysql_error());

$db=mysql_select_db(DB_NAME,$con) or die("Failed to connect to MySQL: " . mysql_error());

echo $_GET['id'];
$query = "DELETE FROM ocr WHERE id=".$_GET['id']."";
   echo $query;
   $data = mysql_query ($query)or die(mysql_error()); 
   echo $data;
   if($data) {
   	//echo "string";
     header("Location: http://localhost/Lamp/mainpage/ocrInfoList.php");
     }

?>

<!-- DELETE FROM table_name WHERE condition; -->