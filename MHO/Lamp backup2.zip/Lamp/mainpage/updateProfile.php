<?php



define('DB_HOST', 'localhost');
define('DB_NAME', 'medicalocr');
define('DB_USER','root');
define('DB_PASSWORD','');
$con=mysql_connect(DB_HOST,DB_USER,DB_PASSWORD) or die("Failed to connect to MySQL: " . mysql_error());

$db=mysql_select_db(DB_NAME,$con) or die("Failed to connect to MySQL: " . mysql_error());
session_start();
      if (!isset($_SESSION['userId'])) {
              header("Location: index.php");
        }
function NewUser() {
 $name = $_POST['name'];  
 $email = $_POST['email']; 
 $contact = $_POST['mobileNumber']; 
 $passsword = $_POST['pwd'];
 $dob = $_POST['dob'];
 $gender = $_POST['gender'];
 $doctorName = $_POST['doctorName'];
 $maritalStatuse = $_POST['maritalStatuse'];
 //echo $gender;
 //$gender = 'M';

 $query = "INSERT INTO users (username,email, password, gender, contact,dob,doctorName,maritalStatuse) VALUES ('$name','$email', '$passsword', '$gender', '$contact','$dob','$doctorName','$maritalStatuse')";
 echo $query;
 $data = mysql_query ($query)or die(mysql_error()); 
 if($data) {
 	echo '<script> alert "YOUR REGISTRATION IS COMPLETED..."; </script>';
  
  	header("Location: index.php"); 
	} 
} 

// echo $_POST['submit'];
if($_POST['submit']=='Submit'){
	$name = $_POST['name'];
	$email = $_POST['email'];
	$mobile = $_POST['mobile'];
	$dob = $_POST['dob'];
	$pwd = $_POST['pwd'];
	$pwd1 = $_POST['pwd1'];
	$doctor = $_POST['doctor'];
	$uid = $_SESSION['userId'];
	echo $uid."<br>";
	if($pwd != $pwd1){
		echo "Password donot match";
	}
	else{
		$query = "UPDATE users
      SET username='$name',email='$email',contact='$mobile',dob= '$dob',password = '$pwd',doctorName='$doctor'
      WHERE userId=$uid";
      echo $query;
      $data = mysql_query ($query)or die(mysql_error());
  		if($data) {
		 	echo 'Submitted';
		  	$_SESSION['username'] = $name;
		  	header("Location: profile.php"); 
			}    
	}

	// $name = $_POST['name'];
}
?>