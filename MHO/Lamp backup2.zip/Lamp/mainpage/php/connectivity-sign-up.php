<?php


define('DB_HOST', 'localhost');
define('DB_NAME', 'medicalocr');
define('DB_USER','root');
define('DB_PASSWORD','');
$con=mysql_connect(DB_HOST,DB_USER,DB_PASSWORD) or die("Failed to connect to MySQL: " . mysql_error());

$db=mysql_select_db(DB_NAME,$con) or die("Failed to connect to MySQL: " . mysql_error());

function NewUser() {
 $name = $_POST['name'];  
 $email = $_POST['email']; 
 $contact = $_POST['mobileNumber']; 
 $passsword = $_POST['pwd'];
 $dob = $_POST['dob'];
 $gender = $_POST['gender'];
 echo $gender;
 //$gender = 'M';

 $query = "INSERT INTO users (username, passsword, gender, contact,dob) VALUES ('$name', '$passsword', '$gender', '$contact','$dob')";
 $data = mysql_query ($query)or die(mysql_error()); 
 if($data) {
  echo "YOUR REGISTRATION IS COMPLETED..."; 
	} 
} 

// Read more: http://mrbool.com/how-to-create-a-sign-up-form-registration-with-php-and-mysql/28675#ixzz5ASTGmfXN


//include("config.php");
//echo $_POST['name'];
function SignUp(){
	//echo $_POST['name'];
	if(empty($_POST['name'])){
		echo "User name is missing! ";
	}
	elseif(empty($_POST['email'])){
		echo "email is missing! ";
	}
	elseif(empty($_POST['mobileNumber'])){
		echo "mobileNumber is missing! ";
	}
	elseif(empty($_POST['dob'])){
		echo "dob is missing! ";
	}
	elseif(empty($_POST['pwd'])){
		echo "pwd is missing! ";
	}
	elseif(empty($_POST['cpwd'])){
		echo "cpwd is missing! ";
	}
	elseif($_POST['pwd'] != $_POST['cpwd']){
		echo "password not matching! ";
	}
	else{
		$query = mysql_query("SELECT * FROM users  WHERE username = '$_POST[name]'") or die(mysql_error());

//Read more: http://mrbool.com/how-to-create-a-sign-up-form-registration-with-php-and-mysql/28675#ixzz5ASQ2ydM8
		//echo $query;
		$row = mysql_fetch_array($query);
		//echo $row;
		if(!$row = mysql_fetch_array($query) or die(mysql_error())) {
		 	NewUser();
		} 
		else { 
			echo "SORRY...YOU ARE ALREADY REGISTERED USER..."; 
		}

		
	}
	


}

if(isset($_POST['submit']))
{
	SignUp();
}

?>