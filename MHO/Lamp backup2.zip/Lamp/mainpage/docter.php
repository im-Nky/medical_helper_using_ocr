<script src="vendor/jquery/jquery.min.js"></script>
<script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
<link href="vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
<!DOCTYPE html>
<!--[if lt IE 7 ]> <html lang="en" class="no-js ie6 lt8"> <![endif]-->
<!--[if IE 7 ]>    <html lang="en" class="no-js ie7 lt8"> <![endif]-->
<!--[if IE 8 ]>    <html lang="en" class="no-js ie8 lt8"> <![endif]-->
<!--[if IE 9 ]>    <html lang="en" class="no-js ie9"> <![endif]-->
<!--[if (gt IE 9)|!(IE)]><!--> 

<html lang="en" class="no-js"> <!--<![endif]-->
    <head>
      <?php 
                  session_start();
                  if (!isset($_SESSION['userId'])) {
                          header("Location: index.php");
                    }
                  $db = mysqli_connect("localhost", "root", "", "medicalocr");
                  $userId=$_SESSION['userId'];
                  $result = mysqli_query($db, "SELECT * FROM users WHERE userId='$userId';");
                  $row = mysqli_fetch_array($result);
                    //echo $_SESSION['username'];
                    // echo $row['image'];

                    // echo $_SESSION['userId'];
                //}
                ?>
        <meta charset="UTF-8" />
        <link href="css/profile.css" rel="stylesheet">
        <link href="css/one-page-wonder.css" rel="stylesheet">
        <!-- <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">  -->
        <title>Medical Helper</title>
        <link rel="shortcut icon" href="img/logo.png" type="image/logo.png" />
		<link rel="stylesheet" type="text/css" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" />
		<link href="https://fonts.googleapis.com/css?family=Raleway:100,100i,200,200i,300,300i,400,400i,500,500i,600,600i,700,700i,800,800i,900,900i" rel="stylesheet">
		
    </head>
    <nav class="navbar navbar-expand-lg navbar-dark navbar-custom fixed-top">
      <div class="container">
        <a class="navbar-brand" href="#">Docters</a>
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarResponsive" aria-controls="navbarResponsive" aria-expanded="false" aria-label="Toggle navigation">
          <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarResponsive">
          <ul class="navbar-nav ml-auto">
            <!-- <li class="nav-item" data-toggle="modal"  href="#" >
              <a class="nav-link" href="#">Home</a>
            </li>
            <li class="nav-item" data-toggle="modal"  href="#" >
              <a class="nav-link" href="#about">About</a>
            </li>
            <li class="nav-item" data-toggle="modal"  href="#" >
              <a class="nav-link" href="#contact">Contact</a>
            </li> -->
            <li class="nav-item"  >
              <a class="nav-link" href="profile.php">Profile</a>
            </li>
            <li class="nav-item" data-toggle="modal">
              <a class="nav-link" href="logout.php">Log Out</a>
            </li>
          </ul>
        </div>
      </div>
    </nav>
    <body>
       <div class="container mx-auto" style="margin-top: 100px; margin-bottom: 100px">
          
  <form style = " position : relative ; height =100 %" id="myFORM"  method="POST">
    <div class="row">  
      <div class="col-md-5 col-lg-5">
          <div class="form-group">
              
              <!-- <label for="sel1">Type of Docter:</label> -->
              <select name="specification" class="form-control" id="sel1">
                <option>None</option>
                <option>Cardiologist</option>
                <option>Consultant</option>
                <option>Physician</option>
                <option>Opthology</option>
                <option>Orthopedic</option>
                <option>Ortho Surgen</option>
                
              </select>
      </div>
    </div>
      <div class="col-md-5 col-lg-5">
        <!-- <label for="sel1">Type of Docter:</label> -->
        <select name="city" class="form-control" id="sel1">
          <option>None</option>
          <option>Agra</option>
          <option>Allahabad</option>
          <option>Pratapgarh</option>
          <option>Fatehpur</option>
          <option>Koshambi</option>
          <option>Azamgarh</option>
          <option>Balia</option>
          <option>Shahjahanpur</option>
          <option>Kanpur</option>
        </select>
      </div>
      <div  class="col-md-2 col-lg-2">
        <input type="submit" id = 'submit' name='submit' value="Submit">
      </div>
    </div>
  </div>
    
  </form>

  </div>
    <?php 

      define('DB_HOST', 'localhost');
      define('DB_NAME', 'medicalocr');
      define('DB_USER','root');
      define('DB_PASSWORD','');
      $con=mysql_connect(DB_HOST,DB_USER,DB_PASSWORD) or die("Failed to connect to MySQL: " . mysql_error());

      $db=mysql_select_db(DB_NAME,$con) or die("Failed to connect to MySQL: " . mysql_error());
      if(isset($_POST["submit"])){
        // echo "submitted";
        //echo $_POST["specification"];
        $specification = $_POST["specification"];
        $city = $_POST["city"];
        if($specification=='None' && $city=='None'){
          $query = mysql_query("SELECT * FROM docter") or die(mysql_error());  
          echo '<table class="table"><thead><tr><th>Name</th><th>specialization</th><th>Contact</th><th>address</th></tr></thead><tbody>';
          $row = mysql_fetch_array($query);
          while($row['name']){
            echo "<tr><td>".$row['name']."</td><td>".$row['specialization']."</td><td>".$row['mobile_no']."</td><td>".$row['address']."</td></tr>";  
            $row = mysql_fetch_array($query);
          }
        }
        else if($specification=='None'){
            $query = mysql_query("SELECT * FROM docter  WHERE  address LIKE '%$city%'") or die(mysql_error());
            $row = mysql_fetch_array($query);
            $lat = $row['lat'];
            $lon = $row['lon'];
            echo '<table class="table"><thead><tr><th>Name</th><th>specialization</th><th>Contact</th><th>address</th></tr></thead><tbody>';
            $query = mysql_query("SELECT * FROM docter ORDER BY ((lat-$lat)*(lat-$lat)) + ((lon - $lon)*(lon - $lon)) ASC LIMIT 20") or die(mysql_error());
            // echo $query;
            $row = mysql_fetch_array($query);
            while($row['name']){
              echo "<tr><td>".$row['name']."</td><td>".$row['specialization']."</td><td>".$row['mobile_no']."</td><td>".$row['address']."</td></tr>";
              $row = mysql_fetch_array($query);
            }  
        }
        else if($city=='None'){
            
            echo '<table class="table"><thead><tr><th>Name</th><th>specialization</th><th>Contact</th><th>address</th></tr></thead><tbody>';
            $query = mysql_query("SELECT * FROM docter WHERE specialization LIKE '%$specification%' LIMIT 20") or die(mysql_error());
            // echo $query;
            $row = mysql_fetch_array($query);
            while($row['name']){
              echo "<tr><td>".$row['name']."</td><td>".$row['specialization']."</td><td>".$row['mobile_no']."</td><td>".$row['address']."</td></tr>";
              $row = mysql_fetch_array($query);
            }  
        }
        else{
            $query = mysql_query("SELECT * FROM docter  WHERE  address LIKE '%$city%'") or die(mysql_error());
            $row = mysql_fetch_array($query);
            $lat = $row['lat'];
            $lon = $row['lon'];
            echo '<table class="table"><thead><tr><th>Name</th><th>specialization</th><th>Contact</th><th>address</th></tr></thead><tbody>';
            $query = mysql_query("SELECT * FROM docter WHERE specialization LIKE '%$specification%' ORDER BY ((lat-$lat)*(lat-$lat)) + ((lon - $lon)*(lon - $lon)) ASC LIMIT 10") or die(mysql_error());
            // echo $query;
            $row = mysql_fetch_array($query);
            while($row['name']){
              echo "<tr><td>".$row['name']."</td><td>".$row['specialization']."</td><td>".$row['mobile_no']."</td><td>".$row['address']."</td></tr>";
              $row = mysql_fetch_array($query);
            }  
        }
        

      echo "</tbody></table>";        
        //SELECT * FROM docter ORDER BY ((lat-27.17667)*(lat-27.17667)) + ((lon - 78.008075)*(lon - 78.008075)) ASC LIMIT 3
        // name="specification"
      }
    ?>
    <div style = " height :350px">

  </div>  

 <footer class="py-5 bg-black">
      <div class="container">
        <p class="m-0 text-center text-white small">MNNIT ALLLAHABAD</p>
        <p class="m-0 text-center text-white small">Group 3</p>
      </div>
      <!-- /.container -->
    </footer>

    <!-- Bootstrap core JavaScript -->
    <script src="vendor/jquery/jquery.min.js"></script>
    <script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>    </body>

  </html>