<script src="vendor/jquery/jquery.min.js"></script>
<script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
<link href="vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
<!DOCTYPE html>
<!--[if lt IE 7 ]> <html lang="en" class="no-js ie6 lt8"> <![endif]-->
<!--[if IE 7 ]>    <html lang="en" class="no-js ie7 lt8"> <![endif]-->
<!--[if IE 8 ]>    <html lang="en" class="no-js ie8 lt8"> <![endif]-->
<!--[if IE 9 ]>    <html lang="en" class="no-js ie9"> <![endif]-->
<!--[if (gt IE 9)|!(IE)]><!--> 
<html lang="en" class="no-js"> <!--<![endif]-->
    <head>
        <meta charset="UTF-8" />
        <link href="css/profile.css" rel="stylesheet">
        <link href="css/one-page-wonder.css" rel="stylesheet">
        <!-- <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">  -->
        <title>Medical Helper</title>
        <link rel="shortcut icon" href="img/logo.png" type="image/logo.png" />
        
        <style type="text/css">
          /* layout.css Style */
            .upload-drop-zone {
              height: 200px;
              border-width: 2px;
              margin-bottom: 20px;
            }

            /* skin.css Style*/
            .upload-drop-zone {
              color: #ccc;
              border-style: dashed;
              border-color: #ccc;
              line-height: 200px;
              text-align: center
            }
            .upload-drop-zone.drop {
              color: #222;
              border-color: #222;
            }
        </style>
		<link rel="stylesheet" type="text/css" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" />
		<link href="https://fonts.googleapis.com/css?family=Raleway:100,100i,200,200i,300,300i,400,400i,500,500i,600,600i,700,700i,800,800i,900,900i" rel="stylesheet">
		
    </head>
    <nav class="navbar navbar-expand-lg navbar-dark navbar-custom fixed-top">
      <div class="container">
        <a class="navbar-brand" href="#">View Profile</a>
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarResponsive" aria-controls="navbarResponsive" aria-expanded="false" aria-label="Toggle navigation">
          <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarResponsive">
          <ul class="navbar-nav ml-auto">
            <!-- <li class="nav-item" data-toggle="modal"  href="#" >
              <a class="nav-link" href="#">Home</a>
            </li>
            <li class="nav-item" data-toggle="modal"  href="#" >
              <a class="nav-link" href="#about">About</a>
            </li>
            <li class="nav-item" data-toggle="modal"  href="#" >
              <a class="nav-link" href="#contact">Contact</a>
            </li> -->
            <li  >
              <a class="nav-link" href="checkOCR.php">Use OCR</a>
            </li>
            <li  >
              <a class="nav-link" href="profile.php">Profile</a>
            </li>
            
            <li class="nav-item" data-toggle="modal">
              <a class="nav-link" href="logout.php">Log Out</a>
            </li>
          </ul>
        </div>
      </div>
    </nav>
    <body>
    	<?php 
                  session_start();
                  if (!isset($_SESSION['userId'])) {
                          header("Location: index.php");
                    }
                  $db = mysqli_connect("localhost", "root", "", "medicalocr");
                  $userId=$_SESSION['userId'];
                  $result = mysqli_query($db, "SELECT * FROM ocr WHERE userID='$userId' ORDER BY datetime DESC;");
                  $row = $result->fetch_array();
                  
        ?>

      <div class="container" style="margin-top: 100px; margin-bottom: 100px">
            <div class="panel panel-default">
            	<ul class="list-group">
            		<?php

            		while($row['0']){
                  echo '<div >';
                  
            			echo '<li class="list-group-item">';
                  echo '<span class="pull-right"><font color="red">';
                  echo '<a href="deleteOCR.php/?id='.$row['id'].'">';
                  echo 'X </a></font></span>'; 
                  echo '<span class="pull-left"><font color="red">';
                  echo $row['datetime'].'</font></span><br>';
                  echo "Docter : ".$row['doctor'].'<br><br><br><br>';
                                    
                  echo nl2br($row['ocrtext']);
                  echo '</li>';
                  echo 	'</div>';
            			$row = $result->fetch_array();
            		}
				  
				  	?>
				  
				</ul>
              
            </div>
          </div> <!-- /container -->
    <footer class="py-5 bg-black">
      <div class="container">
        <p class="m-0 text-center text-white small">MNNIT ALLLAHABAD</p>
        <p class="m-0 text-center text-white small">Group 3</p>
      </div>
      <!-- /.container -->
    </footer>
        
    </body>

    </html>