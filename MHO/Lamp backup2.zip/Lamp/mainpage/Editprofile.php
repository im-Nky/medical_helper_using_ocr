<script src="vendor/jquery/jquery.min.js"></script>
<script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
<link href="vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
<!DOCTYPE html>
<!--[if lt IE 7 ]> <html lang="en" class="no-js ie6 lt8"> <![endif]-->
<!--[if IE 7 ]>    <html lang="en" class="no-js ie7 lt8"> <![endif]-->
<!--[if IE 8 ]>    <html lang="en" class="no-js ie8 lt8"> <![endif]-->
<!--[if IE 9 ]>    <html lang="en" class="no-js ie9"> <![endif]-->
<!--[if (gt IE 9)|!(IE)]><!--> 
<html lang="en" class="no-js"> <!--<![endif]-->
    <head>
        <meta charset="UTF-8" />
        <link href="css/profile.css" rel="stylesheet">
        <link href="css/one-page-wonder.css" rel="stylesheet">
        <!-- <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">  -->
        <title>Medical Helper</title>
        <link rel="shortcut icon" href="img/logo.png" type="image/logo.png" />
        
		<link rel="stylesheet" type="text/css" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" />
		<link href="https://fonts.googleapis.com/css?family=Raleway:100,100i,200,200i,300,300i,400,400i,500,500i,600,600i,700,700i,800,800i,900,900i" rel="stylesheet">
		


    <?php 
      session_start();
      if (!isset($_SESSION['userId'])) {
              header("Location: index.php");
        }
        $db = mysqli_connect("localhost", "root", "", "medicalocr");
                  $userId=$_SESSION['userId'];
                  $result = mysqli_query($db, "SELECT * FROM users WHERE userId='$userId';");
                  $row = mysqli_fetch_array($result);
    ?>
    </head>
    <nav class="navbar navbar-expand-lg navbar-dark navbar-custom fixed-top">
      <div class="container">
        <a class="navbar-brand" href="#">Edit Profile</a>
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarResponsive" aria-controls="navbarResponsive" aria-expanded="false" aria-label="Toggle navigation">
          <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarResponsive">
          <ul class="navbar-nav ml-auto">
            <li class="nav-item" data-toggle="modal" data-target="#loginModal">
              <a class="nav-link" href="index.php">Log Out</a>
            </li>
          </ul>
        </div>
      </div>
    </nav>
    <body>
        <div class="container mx-auto" style="margin-top: 100px; margin-bottom: 100px">
      <div class="row" >
      
        <div class="col-xs-12 col-sm-12 col-md-6 col-lg-6 col-xs-offset-0 col-sm-offset-0 col-md-offset-3 col-lg-offset-3 toppad" >
   
   
          <div class="panel panel-info">
            <div class="panel-heading">
              <h3 class="panel-title"><?php echo $row['username']; ?></h3>
            </div>
            <div class="panel-body">
              <div class="row">
                <div class="col-md-4 col-lg-4 " align="center">
                 <?php
                    if($row['image']){
                        echo "<img alt='User pic' src='images/".$row['image']."' class='img-circle img-fluid' height='200' >";
                       // echo <img alt="User Pic" src="images/.'$row['image']'." class="img-circle img-fluid"  height="200">
                    }
                    else
                        echo '<img alt="User Pic" src="img/profile.png" class="img-circle img-fluid"  height="200">'
                 ?>
               </div>

                <div class=" col-md-8 col-lg-8 "> 
                  <div class="modal-body" style=" max-height: calc(100vh - 210px);Fwio" >
                <form class="form-horizontal" method="POST" action="updateProfile.php">
                  <div class="form-group">
                    <!-- <label class="control-label col-sm-2" for="name">Name:</label> -->
                    <div class="col-sm-10">
                      <input type="text" class="form-control" name ="name" id="name" placeholder="Enter name">
                    </div>
                  </div>

                  <div class="form-group">
                    <!-- <label class="control-label col-sm-2" for="email">Email:</label> -->
                    <div class="col-sm-10">
                      <input type="email" class="form-control" name="email" id="email" placeholder="Enter email">
                    </div>
                  </div>
                  <div class="form-group">
                    <!-- <label class="control-label col-sm-2" for="name">Name:</label> -->
                    <div class="col-sm-10">
                      <input type="text" class="form-control" name ="doctor" id="doctor" placeholder="Enter Doctor's name">
                    </div>
                  </div>
                  <div class="form-group">
                    <!-- <label class="control-label col-sm-2" for="email">Phone Num:</label> -->
                    <div class="col-sm-10">
                      <input type="text" class="form-control" name="mobile" id="mobile" placeholder="Enter mobile number">
                    </div>
                  </div>
                  <div class="form-group">
                    <!-- <label class="control-label col-sm-2" for="email">DoB:</label> -->
                    <div class="col-sm-10">
                      <input type="date" class="form-control" name="dob" id="dob" placeholder="Date of Birth">
                    </div>
                  </div>

                  <div class="form-group">
                    <!-- <label class="control-label col-sm-2" for="pwd">Set New Password:</label> -->
                    <div class="col-sm-10"> 
                      <input type="password" class="form-control" name="pwd" id="pwd" placeholder="Enter New Password">
                    </div>
                  </div>
                  <div class="form-group">
                    <!-- <label class="control-label col-sm-2" for="pwd">Confirm New Password:</label> -->
                    <div class="col-sm-10"> 
                      <input type="password" class="form-control" name="pwd1" id="pwd1" placeholder="confirm New Password">
                    </div>
                  </div>
                  <div class="form-group"> 
                    <div class="col-sm-offset-2 col-sm-10" >
                      <input type="submit" id = 'submit1' name='submit' value="Submit">
                      <a href="profile.php" class="btn btn-success" role="button" aria-disabled="true">Go Back</a>
                      <!-- <a href="prescription.php" class="btn btn-success" role="button" aria-disabled="true">Next Page</a> -->
                      
                    </div>
                  </div>
                </form>
            </div>
                     <!-- <a href="profile.php" class="btn btn-success" role="button" aria-disabled="true">Submit</a>
                      <button type="submit" class="btn btn-success">Submit</button></a>
                      <button type="button" class="btn btn-danger" data-dismiss="modal">Close</button> -->
                <!-- <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                <button type="button" class="btn btn-primary">Save changes</button> -->
            <div class="modal-footer">
                <!-- <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                <button type="button" class="btn btn-primary">Save changes</button> -->
            </div>
        </div>
    </div>
</div>
    <?php
        echo "<script>";
        echo "document.getElementById('name').value='".$row['username']."';"; 
        echo "document.getElementById('email').value='".$row['email']."';"; 
        echo "document.getElementById('mobile').value='".$row['contact']."';"; 
        echo "document.getElementById('dob').value='".$row['dob']."';"; 
        echo "document.getElementById('pwd').value='".$row['password']."';"; 
        echo "document.getElementById('pwd1').value='".$row['password']."';"; 
        echo "document.getElementById('doctor').value='".$row['doctorName']."';"; 
        echo "</script>";
    ?>
            
          </div>
        </div>
      </div>
          <footer class="py-5 bg-black">
      <div class="container">
        <p class="m-0 text-center text-white small">MNNIT ALLLAHABAD</p>
        <p class="m-0 text-center text-white small">Group 3</p>
      </div>
      <!-- /.container -->
    </footer>
    </body>

</html>