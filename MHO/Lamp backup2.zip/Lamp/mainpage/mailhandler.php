
<?php
require_once "phpmailer/PHPMailerAutoload.php";
$mail = new PHPMailer();

define('DB_HOST', 'localhost');
define('DB_NAME', 'medicalocr');
define('DB_USER','root');
define('DB_PASSWORD','');
$con=mysql_connect(DB_HOST,DB_USER,DB_PASSWORD) or die("Failed to connect to MySQL: " . mysql_error());

$db=mysql_select_db(DB_NAME,$con) or die("Failed to connect to MySQL: " . mysql_error());



function saveMessage(){
	//echo $_POST['name'];
	if(empty($_POST['name'])){
		echo "User name is missing! ";
	}

	elseif(empty($_POST['email'])){
		echo "email is missing! ";
	}
	elseif(empty($_POST['phone'])){
		echo "phone is missing! ";
	}
	elseif(empty($_POST['message'])){
		echo "message is missing! ";
	}
	else{

		$mail = new PHPMailer();
		$mail->SMTPDebug = 3;                               
		//Set PHPMailer to use SMTP.
		$mail->isSMTP();            
		//Set SMTP host name                          
		$mail->Host = "smtp.gmail.com";
		//Set this to true if SMTP host requires authentication to send email
		$mail->SMTPAuth = true;                          
		//Provide username and password     
		$mail->Username = "vibhutipratapsingh@gmail.com";                 
		$mail->Password = "#mirandakerr32";                           
		//If SMTP requires TLS encryption then set it
		$mail->SMTPSecure = "tls";                           
		//Set TCP port to connect to 
		$mail->Port = 587;                                   

		$mail->From = "vibhutipratapsingh@gmail.com";
		$mail->FromName = "Vibhuti pratap Singh";

		$mail->addAddress($_POST['email']);

		$mail->isHTML(true);

		$mail->Subject = "Reply from MedicalOCR";
		$mail->Body = "<i>We we contact you as soon as possible</i>";
		//$mail->AltBody = "This is the plain text version of the email content";

		if(!$mail->send()) 
		{
		    echo "Mailer Error: " . $mail->ErrorInfo;
		} 
		else 
		{
		    echo "Message has been sent successfully";
		}

		header("Location: index.php");
		$name = $_POST['name'];  
		 $email = $_POST['email']; 
		 $phone = $_POST['phone']; 
		 $message = $_POST['message'];
		 $query = "INSERT INTO messages (name, email, phone, message) VALUES ('$name', '$email', '$phone', '$message')";
		 $data = mysql_query ($query)or die(mysql_error()); 
		 if($data) {
		  echo "MESSAGE SENT"; 
			} 
		}
		
	}
	






if(isset($_POST['submit']))
{
	//echo 'login page';
	saveMessage();
}

?>